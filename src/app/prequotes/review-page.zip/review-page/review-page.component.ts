import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ApiService } from "../../providers/api.service";
@Component({
  selector: 'app-review-page',
  templateUrl: './review-page.component.html',
  styleUrls: ['./review-page.component.css']
})
export class ReviewPageComponent implements OnInit {
  urlSegment: any;
  dataArValue: any;
  ApiResponse: any;
  logo: any;
  Section:number=1;

  constructor(public api: ApiService,
    private router: Router,
    private formBuilder: FormBuilder
  ) { 

    var splitted = this.router.url.split("/");
    if (typeof splitted[1] != "undefined") {
      this.urlSegment = splitted[2];
    }
// console.log(this.urlSegment)
  }

  ngOnInit() {

    this.GetQuoteDetails(this.urlSegment);
  }


  GetQuoteDetails(SearchTerm: any) {
    const formData = new FormData();
    const quoteId = this.urlSegment;

    console.log(quoteId);
    formData.append("quoteId", this.urlSegment);
    
    this.api.IsLoading();
        this.api.HttpPostType("Review_pay/fetch_details", formData).then(
          (result) => {
            this.api.HideLoading();
          this.dataArValue = result['Data'];
          this.logo = result['logo'];
             
    
           
       
          }
      
        );
    
    }

    
  GetProposalApi(SearchTerm: any) {
    const formData = new FormData();
    const quoteId = this.urlSegment;

    // console.log(quoteId);
    formData.append("quoteId", this.urlSegment);
    
    this.api.IsLoading();
        this.api.HttpPostType("Review_pay/index", formData).then(
          (result) => {
            this.api.HideLoading();
          this.ApiResponse = result['Data'];
                 console.log(this.ApiResponse);
                 $("#review_modal").toggleClass("is_visible");       
       
          }
      
        );
    
    }


    ShowHideFunction(Section){
      this.Section=Section;
    }


}
