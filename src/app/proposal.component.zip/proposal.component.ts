import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
 import { ApiService } from "../../providers/api.service";
 
@Component({
  selector: "app-proposal",
  templateUrl: "./proposal.component.html",
  styleUrls: ["./proposal.component.css"],
})
export class ProposalComponent implements OnInit {
  ShowForm = 1;
  Owner_Details_Form: FormGroup;
  isSubmitted: boolean;
  Vehicle_Details_Form: FormGroup;
  Nominee_Details_Form: FormGroup;
  Last_Policy_Details: FormGroup;
  selectedFiles: any;
  Pan_Card_Document: any;
  Pan_Card_Document_image: number;
  Cancel_Cheque: any;
  Cancel_Cheque_image: number;
  Aadhar_card_Front: any;
  Aadhar_card_Front_image: number;
  Aadhar_card_Back: any;
  Aadhar_card_Back_image: number;
  Electricity_Bill: any;
  Electricity_Bill_image: number;
  Reg_Certificate: any;
  Reg_Certificate_image: number;
  Photo: any;
  Photo_image: number;
  Company: any;
  CompanyName: any;
  SalutationData: any;
  MaritalStatus: any;
  StateData: any;
  CityData: any;
  PincodeData: [];
  GenderData: any;
  FinanciarNameData: any;
  FinanciarCityData: any;
  dropdownSettingsingleselect: { singleSelection: boolean; idField: string; textField: string; itemsShowLimit: number; enableCheckAll: boolean; allowSearchFilter: boolean; };
   QuoteId: any;
  QuoteDetails: any;
  PurposalDetails: any;

  constructor(
    public api: ApiService,
    private router: Router,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    
  ) {
    this.dropdownSettingsingleselect = {
      singleSelection: true,
      idField: "code",
      textField: "name",
      itemsShowLimit: 2,
      enableCheckAll: false,
      allowSearchFilter: true,
    };
    this.CompanyName = this.activatedRoute.snapshot.paramMap.get('company');
    this.QuoteId = this.activatedRoute.snapshot.paramMap.get('quotation');
  


    this.Owner_Details_Form = this.formBuilder.group({
      salutation: ["", [Validators.required]],
      first_name: ["", [Validators.required, Validators.pattern("[a-zA-Z ]*$")]],
      last_name: ["", [Validators.required, Validators.pattern("[a-zA-Z ]*$")]],
      gender: ["", [Validators.required]],
      marital_status: ["", [Validators.required]],
      dob: [""],
      email_proposal: [
        "",
        [
          Validators.pattern(
            "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[A-Za-z]{2,4}$"
          ),
        ],
      ],
      mobile_proposal: [
        "",
        [
          Validators.pattern("^((\\+91-?)|0)?[6-9]{1}[0-9]{9}$"),
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      ],
      address1: ["", [Validators.required]],
      address2: ["", [Validators.required]],
      address3: ["", [Validators.required]],

      pincode: ["", [Validators.required]],
      city: ["", [Validators.required]],
      kyc_doc: ["1"],
      state: ["", [Validators.required]],

      
    });

       this.Vehicle_Details_Form = this.formBuilder.group({
      Registration_State_Code: [
        "",
        [Validators.required, Validators.pattern("[a-zA-Z ]*$")],
      ],
      Registration_District_Code: [
        "",
        [Validators.required, Validators.pattern("[0-9 ]*$")],
      ],
      Registration_City_Code: ["", Validators.required],
      Registration_Code: [
        "",
        [Validators.required, Validators.pattern("[0-9 ]*$")],
      ],
      rto_location: ["", [Validators.required]],
      engine_no: ["", [Validators.required]],
      chassies_no: ["", [Validators.required]],
      hypothecation: [""],
      financier_name: [""],
      financier_city: [""],
    });

    this.Nominee_Details_Form = this.formBuilder.group({
      nominee_name: ["", [Validators.required]],
      nominee_gender: ["", [Validators.required]],
      nominee_dob: [""],
      nominee_relation: [""],
    });

    this.Last_Policy_Details = this.formBuilder.group({
      previous_policy_number: ["", [Validators.required]],
      // Previous_Policy_Company_Name: ["", [Validators.required]],
      // End_Date_Of_Policy: ["", [Validators.required]],
      // Previous_Insurance_Claimed: [""],
    });
  }

  ngOnInit() {
    this.PurposalData('salutation');
    this.PurposalData('marital_status');
    // this.PurposalData('state');
    // this.PurposalData('city');
    this.PurposalData('pincode');
    this.PurposalData('gender');
    this.PurposalData('insurer');
    this.PurposalData('insurer_city');
    
    this.PurposalDataFetch();
    this.PurposalPincode('');

  }
  get formControls1() {
    return this.Owner_Details_Form.controls;
  }
  get formControls2() {
    return this.Vehicle_Details_Form.controls;
  }
  get formControls3() {
    return this.Nominee_Details_Form.controls;
  }
  get formControls4() {
    return this.Last_Policy_Details.controls;
  }
  AddForm(Section) {
    this.isSubmitted = true;

    if (Section == 0) {
      this.ShowForm = 1;
    }

    if (Section == 1) {
      if (this.Owner_Details_Form.invalid) {
        return;
      } else {
        var fields1 = this.Owner_Details_Form.value;
        this.ShowForm = Section + 1;
      }
    }

    if (Section == 2) {
      if (this.Vehicle_Details_Form.invalid) {
        return;
      } else {
        var fields2 = this.Vehicle_Details_Form.value;
        this.ShowForm = Section + 1;
      }
    }

    if (Section == 3) {
      if (this.Nominee_Details_Form.invalid) {
        return;
      } else {
        var fields3 = this.Nominee_Details_Form.value;
        this.ShowForm = Section + 1;
      }
    }

    if (Section == 4) {
      if (this.Last_Policy_Details.invalid) {
        return;
      } else {
        var fields4 = this.Last_Policy_Details.value;
        this.ShowForm = Section + 1;
      }
    }
    
  }

  UploadDocs(event, Type) {
    this.selectedFiles = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      console.log(this.selectedFiles);
      console.log(this.selectedFiles.name);
      var str = this.selectedFiles.name;
      var ar = str.split(".");
      console.log(ar);
      var ext;
      for (var i = 0; i < ar.length; i++) ext = ar[i].toLowerCase();
      console.log(ext);

      if (ext == "png" || ext == "jpeg" || ext == "jpg" || ext == "pdf") {
        console.log("Extenstion is vaild !");
        var file_size = event.target.files[0]["size"];
        const Total_Size = Math.round(file_size / 1024);
        // alert(Total_Size);
        console.log(Total_Size + " kb");

        if (Total_Size >= 10240) {
          // allow only 2 mb

          this.api.Toast("Error", "File size is greater than 10 mb");

          if (Type == "Pan_Card_Document") {
            this.Pan_Card_Document = this.selectedFiles;
            this.Pan_Card_Document_image = 1;
          }
          if (Type == "Cancel_Cheque") {
            this.Cancel_Cheque = this.selectedFiles;
            this.Cancel_Cheque_image = 1;
          }
          if (Type == "Aadhar_card_Front") {
            this.Aadhar_card_Front = this.selectedFiles;
            this.Aadhar_card_Front_image = 1;
          }
          if (Type == "Aadhar_card_Back") {
            this.Aadhar_card_Back = this.selectedFiles;
            this.Aadhar_card_Back_image = 1;
          }
          if (Type == "Electricity_Bill") {
            this.Electricity_Bill = this.selectedFiles;
            this.Electricity_Bill_image = 1;
          }
          if (Type == "Reg_Certificate") {
            this.Reg_Certificate = this.selectedFiles;
            this.Reg_Certificate_image = 1;
          }
          if (Type == "Photo") {
            this.Photo = this.selectedFiles;
            this.Photo_image = 1;
          }
        } else {
          console.log("Extenstion is not vaild !");

          this.api.Toast(
            "Error",
            "Please choose vaild file ! Example :- PNG,JPEG,JPG,PDF"
          );
        }
      }
    }
  }

  PurposalData(SearchCondition) {
 
    const formData = new FormData();

    formData.append("type", SearchCondition);
    formData.append("company", this.CompanyName);
 
    // this.api.IsLoading();
    this.api.HttpPostType("Api_master/masterData", formData).then(
      (result) => {
        // this.api.HideLoading();

        // console.log(result);
        if (result["status"] == 1) {

          if(SearchCondition =='salutation'){
            this.SalutationData=result["Data"];
          }
          if(SearchCondition =='marital_status'){
            this.MaritalStatus=result["Data"];
          }

          // if(SearchCondition =='state'){
          //   this.StateData=result["Data"];
          // } 
          // if(SearchCondition =='city'){
          //   this.CityData=result["Data"];
          // }
          if(SearchCondition =='pincode'){
            this.PincodeData=result["Data"];
          }

          if(SearchCondition =='gender'){
            this.GenderData=result["Data"];
          }

          if(SearchCondition =='insurer'){
            this.FinanciarNameData=result["Data"];
          }

          if(SearchCondition =='insurer_city'){
            this.FinanciarCityData=result["Data"];
          }

        } else {
          const Message = "Message";
          this.api.Toast("Warning", result["Message"]);
        }
      },
      (err) => {
        // this.api.HideLoading();
        const newLocal = "Warning";
        this.api.Toast(
          newLocal,
          "Network Error : " + err.name + "(" + err.statusText + ")"
        );
      }
    );
  }


  PurposalPincode(SearchCondition) {
 
    const formData = new FormData();

    formData.append("SearchCondition", SearchCondition);
    formData.append("type", 'Pincode');
    formData.append("company", this.CompanyName);
 
    // this.api.IsLoading();
    this.api.HttpPostType("Api_master/SearchPincodeData", formData).then(
      (result) => {
        // this.api.HideLoading();

        // console.log(result);
        if (result["Status"] == true) {
             this.PincodeData=result["Data"];

        } else {
          const Message = "Message";
          this.api.Toast("Warning", result["Message"]);
        }
      },
      (err) => {
        // this.api.HideLoading();
        const newLocal = "Warning";
        this.api.Toast(
          newLocal,
          "Network Error : " + err.name + "(" + err.statusText + ")"
        );
      }
    );
  }

 

  PurposalDataFetch() {
 
    const formData = new FormData();

    formData.append("QuoteId", this.QuoteId);
    formData.append("company", this.CompanyName);
 
    // this.api.IsLoading();
    this.api.HttpPostType("Proposal/digit", formData).then(
      (result) => {
        // this.api.HideLoading();

        // console.log(result);
        if (result["Status"] == true) {

          this.QuoteDetails = result['Data']['details'][0];
          this.PurposalDetails = result['Data']['details_user'];

         console.log(result['Data']);
        } else {
          const Message = "Message";
          this.api.Toast("Warning", result["Message"]);
        }
      },
      (err) => {
        // this.api.HideLoading();
        const newLocal = "Warning";
        this.api.Toast(
          newLocal,
          "Network Error : " + err.name + "(" + err.statusText + ")"
        );
      }
    );
  }

  
}
